/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema_29_gen_18;

import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import tema_29_gen_18.Exception.PuntoException;

/**
 *
 * @author Alberto
 */

//////////////////////////////////////////////////
//DA RIGUARDARE: https://codereview.stackexchange.com/questions/72273/using-comparator-with-3-conditions-at-the-same-time
//////////////////////////////////////////////////

public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Sistema s = new Sistema();
        Hub h1 = new Hub("hub1");
        Locker l1 = new Locker("lock1");
        Hub h2 = new Hub("hub2");
        Locker l2 = new Locker("lock2");
        
        s.add_punto(h1);
        s.add_punto(h2);
        s.add_punto(l1);
        s.add_punto(l2);
        
        Box b1 = new Box(10, "box1");
        Box b2 = new Box(20, "box2");
        Box b3 = new Box(30, "box3");
        Box b4 = new Box(40, "box4");
        Box b5 = new Box(20, "box5");
        
        l1.add_box(b1);
        l1.add_box(b3);
        l1.add_box(b2);  //SE ADDO LO STESSO BOX (!!STESSA ISTANZA!!) è COME SE I 2 LOCKER LO AVESSERO IN COMUNEEEEEEEEEEEEE!!!!!
        l2.add_box(b5);
        l2.add_box(b4);
        
        Pacco p1 = new Pacco("p1", 40);
        Pacco p2 = new Pacco("p2", 10);
        
        System.out.println(s.punti_ok(p1));  //mi aspetto che lock1 non accetti il pacco ->DEPOSITAEXCEPTION
        GregorianCalendar data = new GregorianCalendar(2019, 0, 15);
        try {
            System.out.println(s.deposita(p1, l2, data));  //deposito il pacco da 40 su l2
        } catch (PuntoException ex) {
            System.err.println(ex);
        }
       
        try {
            System.out.println(s.deposita(p1, l2,data)); //provo a ridepositarlo, non ci sono piu box con quella dimensione -->depositoexception
        } catch (PuntoException ex) { //allora prenderà puntoexception
            System.err.println(ex);
        }
         
        
        try {
            System.out.println(s.deposita(p2, l2,data));  //ok, ora i tutti i box del lock2 sono occupati
        } catch (PuntoException ex) {
            System.err.println(ex);
        }
         
        try {
            System.out.println(s.deposita(p2, l2, data));  //eccezioni!
        } catch (PuntoException ex) {
            System.err.println(ex);
        }
        
        
        System.out.println(s.stato());
        s.rispedisci();
        System.out.println(s.stato());
        
        try {
            System.out.println(s.deposita(p2, l2, data));  //deposito il pacco da 40 su l2
        } catch (PuntoException ex) {
            System.err.println(ex);
        }
        System.out.println(s.stato());
        
        
    }
    
}
