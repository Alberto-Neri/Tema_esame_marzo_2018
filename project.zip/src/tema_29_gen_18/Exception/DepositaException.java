/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema_29_gen_18.Exception;

import tema_29_gen_18.PuntoRitiro;

/**
 *
 * @author Alberto
 */
public class DepositaException extends Exception {

    /**
     * Creates a new instance of <code>DepositaException</code> without detail
     * message.
     */
    public DepositaException(PuntoRitiro p) {
        super("DepositaException su: "+p.getNome());
    }

    /**
     * Constructs an instance of <code>DepositaException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public DepositaException(String msg) {
        super(msg);
    }
}
