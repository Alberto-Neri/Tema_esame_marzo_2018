/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema_29_gen_18;

import java.util.ArrayList;
import java.util.GregorianCalendar;

/**
 *
 * @author Alberto
 */
public class Hub extends PuntoRitiro{
    private ArrayList<Pacco>pacchi;

    public Hub(String nome) {
        super(nome);
        pacchi = new ArrayList<>();
        
    }

    @Override
    public boolean deposita(Pacco c, GregorianCalendar data) {
        pacchi.add(c);
        c.setData_deposito(data);
        return true;
    }

    @Override
    public void rispedisci() {
        GregorianCalendar today = new GregorianCalendar();
        for (Pacco p:pacchi) {
            if (today.after(p.getData_ritiro())) {  //rimuovo il pacco
                pacchi.remove(p);
            }
        }
    }

    @Override
    public String stato() {
        String a=this.toString()+" contiene: \n";
        for (Pacco p:pacchi) {
            a = a.concat(p.getCodice()+"\n");
        }
        return a.concat("e ci sarà sempre spazio\n");
    }
    
    
}
