/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema_29_gen_18;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author Alberto
 */
public class Pacco {
    private String codice;
    private double dimensione;
    private GregorianCalendar data_deposito, data_ritiro;
    

    public Pacco(String codice, double dimensione) {
        this.codice = codice;
        this.dimensione = dimensione;
    }

    public String getCodice() {
        return codice;
    }

    public double getDimensione() {
        return dimensione;
    }

    public void setData_deposito(GregorianCalendar data_deposito) {
        this.data_deposito = data_deposito;
        this.data_deposito.add(Calendar.DATE, 3);  //questo metodo ritorna void quindi non potevo fare tutto su una riga
        this.data_ritiro = data_deposito;
    }

    public GregorianCalendar getData_deposito() {
        return data_deposito;
    }

    public GregorianCalendar getData_ritiro() {
        return data_ritiro;
    }
    
    
}
