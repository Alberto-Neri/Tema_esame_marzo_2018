/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema_29_gen_18;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import tema_29_gen_18.Exception.DepositaException;

/**
 *
 * @author Alberto
 */
public class Locker extends PuntoRitiro{
    private ArrayList<Box>box;
    
    public Locker(String nome) {
        super(nome);
        box = new ArrayList<Box>();
    }
    
    public void add_box(Box b){
        box.add(b);
    }
    
    public Box trova_box(Pacco c) throws DepositaException{
        Collections.sort(this.box, new Comparator<Box>() {  //prima ordino i box dal piu piccolo al piu grande
            @Override
            public int compare(Box o1, Box o2) {
                return (int) (o1.getDimensione()-o2.getDimensione());
            }
        });
        
        int i = 0; //controlla se trova un box
        for (Box b:box) {  //ciclo sui box di questo locker, se ne esiste uno di dimensioni adeguate --> deposito
            
            if (c.getDimensione() <= b.getDimensione() && b.isPieno()==false){  //posso depositare
                i++;
                return b;
            } 
        }
        //se finisce il ciclo senza ritornare allora non ci sono box disponibili!
        throw new DepositaException(this);  //modifico il messagio di exception cosi che mi dica quale punto crea l'eccezione
        
    }
    
    @Override
    public boolean deposita(Pacco c, GregorianCalendar data) {
        
        Box b;
        try {
            b = trova_box(c);
            b.deposita(c);
            c.setData_deposito(data);  //setto la data di deposito del pacco
            return true;
        } catch (DepositaException ex) { //se trova l'eccezione non fa neanche le altre cose
            System.err.println(ex);
        }
        return false;  //se prende l eccezione ritorna falso
    }

    @Override
    public void rispedisci() {  //devo controllare se sono già passati 3 giorni dal deposito
        GregorianCalendar today = new GregorianCalendar();
        for (Box b:box){
            if (b.isPieno()) {
                if (today.after(b.getPacco().getData_ritiro())) {  //se la data attuale è superiore a quella di ritiro, svuoto il box
                    b.rispedisci();
                    
                } 
            }
        }
        
    }
    
    public String stato(){
        String a=this.toString()+": \n";
        for (Box b:box){
           if (b.isPieno()) 
            a=a.concat(b.getNome()+": "+b.getPacco().getCodice()+"\n");
           else 
             a=a.concat(b.getNome()+": vuoto \n");
        }
        return a;
    }
    
    
}
