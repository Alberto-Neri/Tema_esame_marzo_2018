/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema_29_gen_18;

/**
 *
 * @author Alberto
 */
public class Box {
    private double dimensione;
    private boolean pieno;
    private Pacco pacco;
    private String nome;

    public Box(double dimensione, String nome) {
        this.dimensione = dimensione;
        this.pieno = false;
        this.nome = nome;
    }

    public double getDimensione() {
        return dimensione;
    }

    public boolean isPieno() {
        return pieno;
    }

    public Pacco getPacco() {
        return pacco;
    }
    
    public void deposita(Pacco c){
        this.pacco = c;
        this.pieno = true;
    }
    
    public void rispedisci(){
        this.pacco = null;
        this.pieno = false;
    }

    public String getNome() {
        return nome;
    }
    
}
