/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema_29_gen_18.Exception;

/**
 *
 * @author Alberto
 */
public class PuntoException extends Exception {

    /**
     * Creates a new instance of <code>PuntoException</code> without detail
     * message.
     */
    public PuntoException() {
        super("PuntoException");
    }

    /**
     * Constructs an instance of <code>PuntoException</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public PuntoException(String msg) {
        super(msg);
    }
}
