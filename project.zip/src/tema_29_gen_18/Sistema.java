/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema_29_gen_18;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import tema_29_gen_18.Exception.DepositaException;
import tema_29_gen_18.Exception.PuntoException;

/**
 *
 * @author Alberto
 */
public class Sistema {
    private ArrayList<PuntoRitiro> punti;

    public Sistema() {
        punti = new ArrayList<>();
    }
    
    public void add_punto(PuntoRitiro p){
        punti.add(p);
    }
    
    public ArrayList<PuntoRitiro> trova_punti_ok(Pacco p) {
        ArrayList<PuntoRitiro> punti_ok = new ArrayList<>();
        
        for (PuntoRitiro punto:punti) {
            if (punto instanceof Hub){
                punti_ok.add(punto);
            } else {
                Locker l = (Locker) punto;
                
                try {
                    if (l.trova_box(p) != null){
                        punti_ok.add(punto);
                    }
                } catch (DepositaException ex) {
                    System.err.println(ex);
                }
            }
                
        }
        return punti_ok;
    }
    
    public String punti_ok(Pacco p){
        String a = "Punti ritiro disponibili per pacco "+p.getCodice()+": \n";
        ArrayList<PuntoRitiro> punti_ok = trova_punti_ok(p);
        
        for (PuntoRitiro punto: punti_ok){
            a = a.concat(punto.toString() +"\n");  //DEVO FARE IL TO_STRING DI TUTTI I PUNTI!!
        }
        
        return a;
    }
    
    public String deposita(Pacco p, PuntoRitiro punto, GregorianCalendar date) throws PuntoException{
        
        if (punto.deposita(p, date)){
            /*PuntoRitiro p_ok = punti.get(punti.indexOf(punto));
            p_ok.deposita(p, new GregorianCalendar()); */
            return "pacco "+p.getCodice() +" depositato presso "+punto;
        }
        else 
            throw new PuntoException();
       
    }
    
    public void rispedisci() {
        for (PuntoRitiro punto:punti){
            punto.rispedisci();
        }
    }
    
    public String stato(){
    String a="";
    for (PuntoRitiro punto:punti){
        a = a.concat(punto.stato());
    }
    return a;
    }
    
}
